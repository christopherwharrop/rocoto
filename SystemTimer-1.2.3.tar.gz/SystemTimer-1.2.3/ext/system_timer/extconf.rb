#!/usr/bin/env ruby
require 'mkmf'
create_makefile("system_timer_native")
