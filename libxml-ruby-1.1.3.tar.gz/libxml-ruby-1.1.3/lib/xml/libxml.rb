# This is here for backward compatibility.
#
# TODO: DEPRECATE!

require 'libxml.rb'

include LibXML

