/* $Id: ruby_xml_xpath_context.h 758 2009-01-25 20:36:03Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_XPATH_CONTEXT__
#define __RXML_XPATH_CONTEXT__

extern VALUE cXMLXPathContext;
void rxml_init_xpath_context(void);

#endif
