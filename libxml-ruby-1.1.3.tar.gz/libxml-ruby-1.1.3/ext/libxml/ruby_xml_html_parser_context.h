/* $Id: ruby_xml_parser_context.h 666 2008-12-07 00:16:50Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_HTML_PARSER_CONTEXT__
#define __RXML_HTML_PARSER_CONTEXT__

extern VALUE cXMLHtmlParserContext;

void rxml_init_html_parser_context(void);

#endif
