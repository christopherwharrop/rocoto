/* $Id$ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_XPATH_EXPRESSION__
#define __RXML_XPATH_EXPRESSION__

extern VALUE cXMLXPathExpression;

void rxml_init_xpath_expression(void);

#endif
