/* $Id: ruby_xml_sax_parser.h 666 2008-12-07 00:16:50Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_SAX2_HANDLER__
#define __RXML_SAX2_HANDLER__

extern xmlSAXHandler rxml_sax_handler;

void rxml_init_sax2_handler(void);

#endif
