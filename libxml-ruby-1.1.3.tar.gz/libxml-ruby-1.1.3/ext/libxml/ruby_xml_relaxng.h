#ifndef __RXML_RELAXNG__
#define __RXML_RELAXNG__

#include <libxml/relaxng.h>

extern VALUE cXMLRelaxNG;

void  rxml_init_relaxng(void);
#endif

