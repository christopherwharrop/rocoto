/* $Id: ruby_xml_parser.h 758 2009-01-25 20:36:03Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER__
#define __RXML_PARSER__

#define MAX_LIBXML_FEATURES_LEN 50

extern VALUE cXMLParser;

void rxml_init_parser();

#endif
