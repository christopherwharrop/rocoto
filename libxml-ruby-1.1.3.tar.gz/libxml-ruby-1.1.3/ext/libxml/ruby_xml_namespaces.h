/* $Id: ruby_xml_ns.h 612 2008-11-21 08:01:29Z cfis $ */

/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_NAMESPACES__
#define __RXML_NAMESPACES__

extern VALUE cXMLNamespaces;

void rxml_init_namespaces(void);
#endif
