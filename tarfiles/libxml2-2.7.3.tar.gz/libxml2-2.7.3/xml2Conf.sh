#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/blhome/harrop/libxml2-2.7.3/lib"
XML2_LIBS="-lxml2  -lpthread  -liconv -lm "
XML2_INCLUDEDIR="-I/blhome/harrop/libxml2-2.7.3/include/libxml2"
MODULE_VERSION="xml2-2.7.3"

