/* Don't nuke this block!  It is used for automatically updating the
 * versions below. VERSION = string formatting, VERNUM = numbered
 * version for inline testing: increment both or none at all.*/
#define RUBY_LIBXML_VERSION  "2.3.3"
#define RUBY_LIBXML_VERNUM   233
#define RUBY_LIBXML_VER_MAJ   2
#define RUBY_LIBXML_VER_MIN   3
#define RUBY_LIBXML_VER_MIC   3
#define RUBY_LIBXML_VER_PATCH 0
