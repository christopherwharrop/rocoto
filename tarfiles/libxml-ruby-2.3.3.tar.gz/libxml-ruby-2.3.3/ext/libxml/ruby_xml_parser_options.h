/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER_OPTIONS__
#define __RXML_PARSER_OPTIONS__

#define MAX_LIBXML_FEATURES_LEN 50

extern VALUE mXMLParserOptions;

void rxml_init_parser_options();

#endif
