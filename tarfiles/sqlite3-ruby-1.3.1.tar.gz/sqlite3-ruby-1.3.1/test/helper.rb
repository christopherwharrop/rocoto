require 'sqlite3'
require 'test/unit'
require 'iconv'
