module RubySL
  module Date
    VERSION = "2.0.9"
  end
end
