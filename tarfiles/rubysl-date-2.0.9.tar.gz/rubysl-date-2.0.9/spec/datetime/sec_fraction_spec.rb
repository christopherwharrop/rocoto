require 'date'

describe "DateTime#sec_fraction" do
  it "needs to be reviewed for spec completeness"
end
