require 'date'

describe "DateTime#to_datetime" do
  it "needs to be reviewed for spec completeness"
end
