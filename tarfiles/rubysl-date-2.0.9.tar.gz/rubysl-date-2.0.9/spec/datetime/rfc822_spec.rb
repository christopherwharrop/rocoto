require 'date'

describe "DateTime.rfc822" do
  it "needs to be reviewed for spec completeness"
end
