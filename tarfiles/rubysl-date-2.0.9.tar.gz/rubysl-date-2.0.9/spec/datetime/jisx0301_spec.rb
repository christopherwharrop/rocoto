require 'date'

describe "DateTime.jisx0301" do
  it "needs to be reviewed for spec completeness"
end

describe "DateTime#jisx0301" do
  it "needs to be reviewed for spec completeness"
end
