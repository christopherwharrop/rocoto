require 'date'

describe "DateTime#to_time" do
  it "needs to be reviewed for spec completeness"
end
