require 'date'

describe "DateTime.jd" do
  it "needs to be reviewed for spec completeness"
end
