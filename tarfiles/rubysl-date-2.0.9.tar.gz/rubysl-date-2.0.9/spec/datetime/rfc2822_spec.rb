require 'date'

describe "DateTime.rfc2822" do
  it "needs to be reviewed for spec completeness"
end
