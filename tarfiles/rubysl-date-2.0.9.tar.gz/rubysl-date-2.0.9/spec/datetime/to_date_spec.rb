require 'date'

describe "DateTime#to_date" do
  it "needs to be reviewed for spec completeness"
end
