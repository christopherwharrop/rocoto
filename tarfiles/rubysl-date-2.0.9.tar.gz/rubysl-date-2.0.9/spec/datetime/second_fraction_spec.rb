require 'date'

describe "DateTime#second_fraction" do
  it "needs to be reviewed for spec completeness"
end
