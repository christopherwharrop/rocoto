require 'date'

describe "DateTime#new_offset" do
  it "needs to be reviewed for spec completeness"
end
