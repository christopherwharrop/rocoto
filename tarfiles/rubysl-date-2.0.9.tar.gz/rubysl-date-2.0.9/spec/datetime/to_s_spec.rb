require 'date'

describe "DateTime#to_s" do
  it "needs to be reviewed for spec completeness"
end
