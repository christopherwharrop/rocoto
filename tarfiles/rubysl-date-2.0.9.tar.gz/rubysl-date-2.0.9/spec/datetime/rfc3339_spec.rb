require 'date'

describe "DateTime.rfc3339" do
  it "needs to be reviewed for spec completeness"
end

describe "DateTime#rfc3339" do
  it "needs to be reviewed for spec completeness"
end
