require 'date'

describe "Date.today" do
  it "needs to be reviewed for spec completeness"
end
