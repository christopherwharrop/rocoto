require 'date'

describe "Date.jd_to_wday" do
  it "needs to be reviewed for spec completeness"
end
