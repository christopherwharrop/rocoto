require 'date'

describe "Date#mjd" do
  it "needs to be reviewed for spec completeness"
end
