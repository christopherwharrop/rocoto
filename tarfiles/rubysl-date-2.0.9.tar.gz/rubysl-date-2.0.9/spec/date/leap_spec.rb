require 'date'

describe "Date#leap?" do
  it "needs to be reviewed for spec completeness"
end

describe "Date.leap?" do
  it "needs to be reviewed for spec completeness"
end
