require 'date'

describe "Date::Infinity#nan?" do
  it "needs to be reviewed for spec completeness"
end
