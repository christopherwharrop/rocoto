require 'date'

describe "Date::Infinity#abs" do
  it "needs to be reviewed for spec completeness"
end
