require 'date'

describe "Date::Infinity#-@" do
  it "needs to be reviewed for spec completeness"
end
