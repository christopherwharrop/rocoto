require 'date'

describe "Date::Infinity#d" do
  it "needs to be reviewed for spec completeness"
end
