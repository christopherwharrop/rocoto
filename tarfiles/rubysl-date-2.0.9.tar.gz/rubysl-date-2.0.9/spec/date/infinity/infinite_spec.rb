require 'date'

describe "Date::Infinity#infinite?" do
  it "needs to be reviewed for spec completeness"
end
