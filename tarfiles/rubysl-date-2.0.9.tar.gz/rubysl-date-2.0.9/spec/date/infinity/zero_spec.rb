require 'date'

describe "Date::Infinity#zero?" do
  it "needs to be reviewed for spec completeness"
end
