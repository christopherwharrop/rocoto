require 'date'

describe "Date#asctime" do
  it "needs to be reviewed for spec completeness"
end
