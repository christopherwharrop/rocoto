require 'date'

describe "Date#cwday" do
  it "needs to be reviewed for spec completeness"
end
