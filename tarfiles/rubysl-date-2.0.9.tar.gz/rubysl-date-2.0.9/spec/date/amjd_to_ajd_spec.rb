require 'date'

describe "Date.amjd_to_ajd" do
  it "needs to be reviewed for spec completeness"
end
