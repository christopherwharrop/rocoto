require 'date'

describe "Date#day_fraction" do
  it "needs to be reviewed for spec completeness"
end
