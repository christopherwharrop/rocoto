require 'date'

describe "Date.commercial_to_jd" do
  it "needs to be reviewed for spec completeness"
end
