require 'date'

describe "Date#<<" do
  it "needs to be reviewed for spec completeness"
end
