require 'date'

describe "Date.time_to_day_fraction" do
  it "needs to be reviewed for spec completeness"
end
