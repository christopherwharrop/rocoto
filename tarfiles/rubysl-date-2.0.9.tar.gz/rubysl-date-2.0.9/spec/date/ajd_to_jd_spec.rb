require 'date'

describe "Date.ajd_to_jd" do
  it "needs to be reviewed for spec completeness"
end
