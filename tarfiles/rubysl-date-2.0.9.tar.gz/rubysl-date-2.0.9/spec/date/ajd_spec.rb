require 'date'

describe "Date#ajd" do
  it "needs to be reviewed for spec completeness"
end
