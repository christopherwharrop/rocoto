require 'date'

describe "Date#to_s" do
  it "needs to be reviewed for spec completeness"
end
