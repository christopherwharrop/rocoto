require 'date'

describe "Date#succ" do
  it "needs to be reviewed for spec completeness"
end
