require 'date'

describe "Date.day_fraction_to_time" do
  it "needs to be reviewed for spec completeness"
end
