require 'date'

describe "Date.ordinal_to_jd" do
  it "needs to be reviewed for spec completeness"
end
