require 'date'

describe "Date.jd_to_ajd" do
  it "needs to be reviewed for spec completeness"
end
