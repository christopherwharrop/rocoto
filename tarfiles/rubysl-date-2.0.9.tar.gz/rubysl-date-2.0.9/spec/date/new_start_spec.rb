require 'date'

describe "Date#new_start" do
  it "needs to be reviewed for spec completeness"
end
