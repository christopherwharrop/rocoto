require 'date'

ruby_version_is "" ... "1.9" do
  describe "Date#ns?" do
    it "needs to be reviewed for spec completeness"
  end

  describe "Date.ns?" do
    it "needs to be reviewed for spec completeness"
  end
end
