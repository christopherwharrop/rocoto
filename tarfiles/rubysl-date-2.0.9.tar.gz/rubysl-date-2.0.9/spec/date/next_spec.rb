require 'date'

describe "Date#next" do
  it "needs to be reviewed for spec completeness"
end
