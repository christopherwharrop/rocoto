require 'date'

describe "Date#ld" do
  it "needs to be reviewed for spec completeness"
end
