require 'date'

describe "Date.jd_to_civil" do
  it "needs to be reviewed for spec completeness"
end
