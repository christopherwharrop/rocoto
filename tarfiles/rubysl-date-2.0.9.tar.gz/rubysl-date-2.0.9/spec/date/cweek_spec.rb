require 'date'

describe "Date#cweek" do
  it "needs to be reviewed for spec completeness"
end
