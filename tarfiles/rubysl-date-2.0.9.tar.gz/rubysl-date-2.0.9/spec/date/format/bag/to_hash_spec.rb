require 'date'

describe "Date::Format::Bag#to_hash" do
  it "needs to be reviewed for spec completeness"
end
