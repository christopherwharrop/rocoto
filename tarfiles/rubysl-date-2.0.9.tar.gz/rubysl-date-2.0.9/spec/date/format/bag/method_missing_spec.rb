require 'date'

describe "Date::Format::Bag#method_missing" do
  it "needs to be reviewed for spec completeness"
end
