require 'date'

describe "Date.ajd_to_amjd" do
  it "needs to be reviewed for spec completeness"
end
