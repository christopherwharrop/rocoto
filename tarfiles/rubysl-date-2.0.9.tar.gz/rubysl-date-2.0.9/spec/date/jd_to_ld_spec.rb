require 'date'

describe "Date.jd_to_ld" do
  it "needs to be reviewed for spec completeness"
end
