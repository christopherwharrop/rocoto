require 'date'

describe "Date#yday" do
  it "needs to be reviewed for spec completeness"
end
