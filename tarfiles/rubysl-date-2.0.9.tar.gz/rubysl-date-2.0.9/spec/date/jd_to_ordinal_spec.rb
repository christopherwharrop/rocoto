require 'date'

describe "Date.jd_to_ordinal" do
  it "needs to be reviewed for spec completeness"
end
