module RubySL
  module ParseDate
    VERSION = "1.0.1"
  end
end
