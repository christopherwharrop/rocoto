/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RUBY_XML_H__
#define __RUBY_XML_H__

extern VALUE mXML;
int rxml_libxml_default_options();
void rxml_init_xml(void);

#endif
