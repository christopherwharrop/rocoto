/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_HTML_PARSER_OPTIONS__
#define __RXML_HTML_PARSER_OPTIONS__

extern VALUE mXMLHtmlParserOptions;

void rxml_init_html_parser_options(void);

#endif
