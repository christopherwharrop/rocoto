/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_PARSER_CONTEXT__
#define __RXML_PARSER_CONTEXT__

extern VALUE cXMLParserContext;

void rxml_init_parser_context(void);

#endif
