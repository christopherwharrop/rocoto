/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_SAX_PARSER__
#define __RXML_SAX_PARSER__

extern VALUE cXMLSaxParser;

void rxml_init_sax_parser(void);

#endif
