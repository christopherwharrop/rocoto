/* Don't nuke this block!  It is used for automatically updating the
 * versions below. VERSION = string formatting, VERNUM = numbered
 * version for inline testing: increment both or none at all.*/
#define RUBY_LIBXML_VERSION  "2.7.0"
#define RUBY_LIBXML_VERNUM   270
#define RUBY_LIBXML_VER_MAJ   2
#define RUBY_LIBXML_VER_MIN   7
#define RUBY_LIBXML_VER_MIC   0
#define RUBY_LIBXML_VER_PATCH 0
