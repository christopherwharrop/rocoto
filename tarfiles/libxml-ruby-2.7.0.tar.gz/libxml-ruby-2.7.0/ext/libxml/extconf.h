#ifndef EXTCONF_H
#define EXTCONF_H
#define HAVE_ZLIB_H 1
#define HAVE_LIBXML_XMLVERSION_H 1
#endif
