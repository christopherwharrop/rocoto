/* Please see the LICENSE file for copyright and distribution information */

#ifndef __RXML_HTML_PARSER__
#define __RXML_HTML_PARSER__

extern VALUE cXMLHtmlParser;

void rxml_init_html_parser(void);

#endif
