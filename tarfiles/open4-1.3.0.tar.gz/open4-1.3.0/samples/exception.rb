require "open4"

Open4::popen4 "noexist"
